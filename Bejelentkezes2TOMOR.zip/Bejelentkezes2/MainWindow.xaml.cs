﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Security.Cryptography;
using MySql.Data.MySqlClient;

namespace Bejelentkezes2
{
    public partial class MainWindow : Window
    {
        public class Data
        {
            public string connectiondata = "server=localhost;database=jelszokezeles;uid=vasarlo2;pwd=vasarlo2";

            public bool adatlekerdezes(string felhasznalo, string jelszo)
            {
                bool jo = false;
                try
                {
                    MySqlConnection conn = new MySqlConnection(connectiondata);
                    conn.Open();
                    string query = "select count(*) from felhasznalok where nev=@param1 and jelszo=@param2";
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@param1", felhasznalo);
                    cmd.Parameters.AddWithValue("@param2", jelszo);
                    int dr = Convert.ToInt32(cmd.ExecuteScalar());
                    if (dr == 1)
                    {
                        jo = true;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Hiba!", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                return jo;
            }
            public string titkosit(string input)
            {
                using (SHA256 sha256Hash = SHA256.Create())
                {
                    byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(input));
                    StringBuilder builder = new StringBuilder();
                    foreach (byte b in bytes)
                    {
                        builder.Append(b.ToString("x2"));
                    }
                    return builder.ToString();
                }
            }
        }
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(felhasznalo.Text) && !string.IsNullOrWhiteSpace(jelszo.Password))
            {
                string felhasznalonevp = felhasznalo.Text;
                string jelszop = jelszo.Password;
                Data peldany = new Data();
                string titkositott = peldany.titkosit(jelszop);
                if (peldany.adatlekerdezes(felhasznalonevp, titkositott))
                {
                    lap lapocska = new lap();
                    lapocska.Show();
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Hiáynos Felhasználónév/Jelszó");
                }
            }
            else
            {
                MessageBox.Show("Hiányos adatok!");
            }
        }
    }
}