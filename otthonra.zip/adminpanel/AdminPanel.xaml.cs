﻿using System;
using System.Data;
using System.Windows;
using MySql.Data.MySqlClient;

namespace AuthApp
{
    public partial class AdminPanel : Window
    {
        private const string ConnectionString = "Server=localhost;Database=auto;Uid=root;Pwd=root;";
        private MySqlDataAdapter adapter;
        private DataTable table;

        public AdminPanel()
        {
            InitializeComponent();
            LoadTables();
        }
        public static class DataTableComparer
        {
            public static bool IsTableEqual(DataTable table1, DataTable table2)
            {
                if (table1.Rows.Count != table2.Rows.Count || table1.Columns.Count != table2.Columns.Count)
                    return false;

                for (int i = 0; i < table1.Rows.Count; i++)
                {
                    for (int j = 0; j < table1.Columns.Count; j++)
                    {
                        if (!Equals(table1.Rows[i][j], table2.Rows[i][j]))
                        {
                            return false;
                        }
                    }
                }
                return true;
            }
        }


        // Táblák betöltése ComboBox-ba
        private void LoadTables()
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection(ConnectionString))
                {
                    conn.Open();
                    string query = "SHOW TABLES;";
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    MySqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        TableSelector.Items.Add(reader.GetString(0));
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hiba történt a táblák betöltésekor: " + ex.Message);
            }
        }

        // Tábla adatainak betöltése DataGrid-be
        private void TableSelector_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (TableSelector.SelectedItem == null) return;

            string selectedTable = TableSelector.SelectedItem.ToString();
            try
            {
                using (MySqlConnection conn = new MySqlConnection(ConnectionString))
                {
                    conn.Open();
                    string query = $"SELECT * FROM {selectedTable};";
                    adapter = new MySqlDataAdapter(query, conn);

                    // Parancsok létrehozása a mentéshez
                    MySqlCommandBuilder builder = new MySqlCommandBuilder(adapter);
                    adapter.InsertCommand = builder.GetInsertCommand();
                    adapter.UpdateCommand = builder.GetUpdateCommand();
                    adapter.DeleteCommand = builder.GetDeleteCommand();

                    table = new DataTable();
                    adapter.Fill(table);

                    DataGridTable.ItemsSource = table.DefaultView;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hiba történt az adatok betöltésekor: " + ex.Message);
            }
        }


        // Adatok mentése az adatbázisba
        private void SaveChanges_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (table != null)
                {
                    // Mentés
                    int rowsUpdated = adapter.Update(table);
                    MessageBox.Show($"{rowsUpdated} sor sikeresen mentve!");

                    // Ellenőrzés: Tábla újratöltése
                    string selectedTable = TableSelector.SelectedItem.ToString();
                    using (MySqlConnection conn = new MySqlConnection(ConnectionString))
                    {
                        conn.Open();
                        string query = $"SELECT * FROM {selectedTable};";
                        MySqlDataAdapter verifyAdapter = new MySqlDataAdapter(query, conn);
                        DataTable refreshedTable = new DataTable();
                        verifyAdapter.Fill(refreshedTable);

                        // Összehasonlítás az eredeti és frissített táblák között
                        if (DataTableComparer.IsTableEqual(table, refreshedTable))
                        {
                            MessageBox.Show("A mentés sikeresen megtörtént, az adatok egyeznek az adatbázissal.");
                        }
                        else
                        {
                            MessageBox.Show("Hiba: A mentés után az adatok nem egyeznek az adatbázissal.");
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Nincs betöltött adat a mentéshez.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hiba történt a mentés során: " + ex.Message);
            }
        }


        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
