﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using MySql.Data.MySqlClient;

namespace Kocsi_App
{
    public class DatabaseHelper
    {
        private string _connectionString;

        public DatabaseHelper(string connectionString)
        {
            _connectionString = connectionString;
        }

        public DataTable Select(string query, Dictionary<string, object> parameters = null)
        {
            DataTable dataTable = new DataTable();
            using (var connection = new MySqlConnection(_connectionString))
            {
                using (var command = new MySqlCommand(query, connection))
                {
                    if (parameters != null)
                    {
                        foreach (var param in parameters)
                        {
                            command.Parameters.AddWithValue(param.Key, param.Value);
                        }
                    }

                    connection.Open();
                    using (var reader = command.ExecuteReader())
                    {
                        dataTable.Load(reader);
                    }
                }
            }
            return dataTable;
        }
    }

    public partial class Foablak : Window
    {
        private DatabaseHelper dbHelper;

        public Foablak()
        {
            InitializeComponent();
            dbHelper = new DatabaseHelper("server=localhost;database=kocsi;uid=root;pwd=root;");
            LoadFilters();
        }

        private void LoadFilters()
        {
            LoadComboBox("SELECT Márka FROM Márkák", MárkaCheckBoxes);
            LoadComboBox("SELECT Szín FROM Színek", SzínCheckBoxes);
            LoadUsageCheckboxes();
            LoadYearCheckboxes();
        }

        private void LoadComboBox(string query, StackPanel targetPanel)
        {
            var dataTable = dbHelper.Select(query);
            foreach (DataRow row in dataTable.Rows)
            {
                CheckBox checkBox = new CheckBox { Content = row[0].ToString(), Foreground = System.Windows.Media.Brushes.White };
                checkBox.Checked += FilterCheckBox_Changed;
                checkBox.Unchecked += FilterCheckBox_Changed;
                targetPanel.Children.Add(checkBox);
            }
        }

        private void LoadUsageCheckboxes()
        {
            LoadComboBox("SELECT Használat FROM Használat", HasználatCheckBoxes);
        }

        private void LoadYearCheckboxes()
        {
            var dataTable = dbHelper.Select("SELECT DISTINCT Évjárat FROM Autók ORDER BY Évjárat");
            foreach (DataRow row in dataTable.Rows)
            {
                CheckBox checkBox = new CheckBox { Content = row["Évjárat"].ToString(), Foreground = System.Windows.Media.Brushes.White };
                checkBox.Checked += FilterCheckBox_Changed;
                checkBox.Unchecked += FilterCheckBox_Changed;
                ÉvjáratCheckBoxes.Children.Add(checkBox);
            }
        }

        private void MárkaCheckBoxes_SelectionChanged(object sender, RoutedEventArgs e)
        {
            if (sender is CheckBox selectedMárka && selectedMárka.IsChecked == true)
            {
                var márka = selectedMárka.Content.ToString();
                LoadModelCheckboxes(márka);
            }
        }

        private void LoadModelCheckboxes(string márka)
        {
            ModellCheckBoxes.Children.Clear();
            var query = "SELECT Modell FROM Modellek WHERE Márka = @márka";
            var parameters = new Dictionary<string, object> { { "@márka", márka } };
            var dataTable = dbHelper.Select(query, parameters);
            foreach (DataRow row in dataTable.Rows)
            {
                CheckBox checkBox = new CheckBox { Content = row["Modell"].ToString(), Foreground = System.Windows.Media.Brushes.White };
                checkBox.Checked += FilterCheckBox_Changed;
                checkBox.Unchecked += FilterCheckBox_Changed;
                ModellCheckBoxes.Children.Add(checkBox);
            }
        }

        private void KilometerSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (sender is Slider slider)
            {
                KilometerMinLabel.Content = KilometerMinSlider.Value.ToString("0") + " km";
                KilometerMaxLabel.Content = KilometerMaxSlider.Value.ToString("0") + " km";
            }
        }

        private void PriceSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            if (sender is Slider slider)
            {
                PriceMinLabel.Content = PriceMinSlider.Value.ToString("0") + " Ft";
                PriceMaxLabel.Content = PriceMaxSlider.Value.ToString("0") + " Ft";
            }
        }

        private void FilterCheckBox_Changed(object sender, RoutedEventArgs e)
        {
            ApplyFilters();
        }

        private void ApplyFilters()
        {
            var query = "SELECT * FROM Autók WHERE 1=1";
            var parameters = new Dictionary<string, object>();

            // Márka szűrő
            var selectedMárkák = MárkaCheckBoxes.Children.OfType<CheckBox>().Where(cb => cb.IsChecked == true).Select(cb => cb.Content.ToString()).ToList();
            if (selectedMárkák.Any())
            {
                query += " AND Márka IN (" + string.Join(",", selectedMárkák.Select((_, i) => "@márka" + i)) + ")";
                for (int i = 0; i < selectedMárkák.Count; i++)
                {
                    parameters.Add("@márka" + i, selectedMárkák[i]);
                }
            }

            // Szín szűrő
            var selectedSzínek = SzínCheckBoxes.Children.OfType<CheckBox>().Where(cb => cb.IsChecked == true).Select(cb => cb.Content.ToString()).ToList();
            if (selectedSzínek.Any())
            {
                query += " AND Szín IN (" + string.Join(",", selectedSzínek.Select((_, i) => "@szín" + i)) + ")";
                for (int i = 0; i < selectedSzínek.Count; i++)
                {
                    parameters.Add("@szín" + i, selectedSzínek[i]);
                }
            }

            // Évjárat szűrő
            var selectedÉvjáratok = ÉvjáratCheckBoxes.Children.OfType<CheckBox>().Where(cb => cb.IsChecked == true).Select(cb => cb.Content.ToString()).ToList();
            if (selectedÉvjáratok.Any())
            {
                query += " AND Évjárat IN (" + string.Join(",", selectedÉvjáratok.Select((_, i) => "@évjárat" + i)) + ")";
                for (int i = 0; i < selectedÉvjáratok.Count; i++)
                {
                    parameters.Add("@évjárat" + i, selectedÉvjáratok[i]);
                }
            }

            // Lekérdezés végrehajtása
            var filteredData = dbHelper.Select(query, parameters);
            MyDataGrid.ItemsSource = filteredData.DefaultView;
        }
    }
}
