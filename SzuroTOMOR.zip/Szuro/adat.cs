﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace Szuro
{
    public class adatkezelo
    {
        static string connectionString = "server=localhost;database=auto_adatbazis;uid=root;pwd=root";

        public void LoadData(DataGrid adatterulet, string Marka, string Hasznalat)
        {
            string query = "SELECT * FROM view1 where (Marka=@Marka OR @Marka IS NULL) and (Hasznalat=@Hasznalat OR @Hasznalat IS NULL)";

            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();

                    using (MySqlCommand cmd = new MySqlCommand(query, conn))
                    {
                        // Paraméterek hozzáadása
                        cmd.Parameters.AddWithValue("@Marka", Marka);
                        cmd.Parameters.AddWithValue("@Hasznalat", Hasznalat);

                        // MySqlDataAdapter példányosítása, és lekérdezés beállítása
                        MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);  // A lekérdezést a cmd adja át az adapternek
                        DataTable dt = new DataTable();

                        // A DataTable feltöltése a lekérdezés eredményével
                        adapter.Fill(dt);

                        // DataGrid frissítése
                        adatterulet.Columns.Clear();
                        adatterulet.ItemsSource = dt.DefaultView;

                        // Oszlopok hozzáadása a DataGridhez
                        adatterulet.Columns.Add(new DataGridTextColumn
                        {
                            Header = "Termék Neve",
                            Binding = new System.Windows.Data.Binding("tnev")
                        });
                        adatterulet.Columns.Add(new DataGridTextColumn
                        {
                            Header = "Termék Márkája",
                            Binding = new System.Windows.Data.Binding("Marka")
                        });
                        adatterulet.Columns.Add(new DataGridTextColumn
                        {
                            Header = "Termék Használata",
                            Binding = new System.Windows.Data.Binding("Hasznalat")
                        });
                    }
                }
            }
            catch (Exception ex)
            {
                // Hibaüzenet kezelése
                Console.WriteLine(ex.Message);
                throw;
            }
        }

        public void LoadCombo(ComboBox lista, string oszlop, string tabla)
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection(connectionString))
                {
                    conn.Open();
                    string query = $"select `{oszlop}` from `{tabla}`";
                    using (MySqlCommand cmd = new MySqlCommand(query,conn))
                    {
                        using (MySqlDataReader dr = cmd.ExecuteReader())
                        {
                            lista.Items.Clear();
                            lista.Items.Add(" ");
                            while (dr.Read())
                            {
                                lista.Items.Add(dr[oszlop].ToString());
                            }
                        }
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        
    }
}