﻿using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Windows;
using System.Windows.Controls;

namespace AuthApp
{
    public partial class AdminPanel : Window
    {
        private const string ConnectionString = "Server=localhost;Database=auto_adatbazis;Uid=root;Pwd=root;";
        private MySqlDataAdapter adapter;
        private DataTable table;

        public AdminPanel()
        {
            InitializeComponent();
            if (TestDatabaseConnection())  // Kapcsolat tesztelése az adatbázishoz
            {
                LoadTables();
            }
        }

        // Adatbázis kapcsolat tesztelése
        private bool TestDatabaseConnection()
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection(ConnectionString))
                {
                    conn.Open();
                    MessageBox.Show("Kapcsolat sikeresen létrejött az adatbázissal.");
                    return true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hiba történt a kapcsolat létrehozásakor: " + ex.Message);
                return false;
            }
        }

        // Táblák betöltése ComboBox-ba
        private void LoadTables()
        {
            try
            {
                using (MySqlConnection conn = new MySqlConnection(ConnectionString))
                {
                    conn.Open();
                    string query = "SHOW TABLES;";
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    MySqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        TableComboBox.Items.Add(reader.GetString(0));
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hiba történt a táblák betöltésekor: " + ex.Message);
            }
        }

        // Tábla adatainak betöltése DataGrid-be
        private void TableComboBox_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (TableComboBox.SelectedItem == null) return;

            string selectedTable = TableComboBox.SelectedItem.ToString();

            if (selectedTable == "autok" || selectedTable == "dolgozo" || selectedTable == "eladok" || selectedTable == "hasznalat" || selectedTable == "jogosultsag" ||
                selectedTable == "markak" || selectedTable == "modellek" || selectedTable == "motorspecifikaciok" || selectedTable == "motortipusok" ||
                selectedTable == "parkolo" || selectedTable == "regisztracio" || selectedTable == "sebessegvaltok" || selectedTable == "szinek")
            {
                try
                {
                    using (MySqlConnection conn = new MySqlConnection(ConnectionString))
                    {
                        conn.Open();
                        string query = $"SELECT * FROM {selectedTable};";
                        adapter = new MySqlDataAdapter(query, conn);

                        // Parancsok létrehozása a mentéshez
                        MySqlCommandBuilder builder = new MySqlCommandBuilder(adapter);
                        adapter.InsertCommand = builder.GetInsertCommand();
                        adapter.UpdateCommand = builder.GetUpdateCommand();
                        adapter.DeleteCommand = builder.GetDeleteCommand();

                        table = new DataTable();
                        adapter.Fill(table);

                        // A DataGrid beállítása
                        CarDataGrid.ItemsSource = table.DefaultView;
                        CarDataGrid.IsReadOnly = false;  // Az adatok szerkeszthetővé tétele
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Hiba történt az adatok betöltésekor: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("A kiválasztott tábla nem létezik vagy hibás!");
            }
        }

        // Adatok mentése az adatbázisba
        private void SaveChanges_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (table != null)
                {
                    // Mentés
                    int rowsUpdated = adapter.Update(table);
                    MessageBox.Show($"{rowsUpdated} sor sikeresen mentve!");
                }
                else
                {
                    MessageBox.Show("Nincs betöltött adat a mentéshez.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hiba történt a mentés során: " + ex.Message);
            }
        }

        // Adat hozzáadása
        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (table != null)
                {
                    // Az új adatot beillesztjük a táblába
                    DataRow newRow = table.NewRow();
                    table.Rows.Add(newRow);
                    CarDataGrid.ItemsSource = table.DefaultView;

                    // Insert parancs végrehajtása a MySQL adatbázisba
                    string query = $"INSERT INTO {TableComboBox.SelectedItem.ToString()} (column_name1, column_name2) VALUES (@value1, @value2)";
                    using (MySqlConnection conn = new MySqlConnection(ConnectionString))
                    {
                        MySqlCommand cmd = new MySqlCommand(query, conn);
                        cmd.Parameters.AddWithValue("@value1", newRow["column_name1"]);
                        cmd.Parameters.AddWithValue("@value2", newRow["column_name2"]);

                        conn.Open();
                        cmd.ExecuteNonQuery();
                    }

                    MessageBox.Show("Új adat sikeresen hozzáadva!");
                }
                else
                {
                    MessageBox.Show("Nincs betöltött adat a hozzáadáshoz.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hiba történt az adat hozzáadásakor: " + ex.Message);
            }
        }

        // Adat módosítása a TextBox-ból
        private void UpdateButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (CarDataGrid.SelectedIndex >= 0)
                {
                    // Kiválasztott sor azonosítása
                    DataRowView selectedRow = (DataRowView)CarDataGrid.SelectedItem;
                    string selectedId = selectedRow.Row["id"].ToString(); // Az id mező alapján módosítunk

                    // A TextBox értékének lekérése a változtatáshoz
                    string newValue = InputTextBox.Text;

                    // SQL UPDATE parancs
                    string query = $"UPDATE {TableComboBox.SelectedItem.ToString()} SET column_name1 = @newValue WHERE id = @id";
                    using (MySqlConnection conn = new MySqlConnection(ConnectionString))
                    {
                        MySqlCommand cmd = new MySqlCommand(query, conn);
                        cmd.Parameters.AddWithValue("@newValue", newValue);
                        cmd.Parameters.AddWithValue("@id", selectedId);

                        conn.Open();
                        cmd.ExecuteNonQuery();
                    }

                    // Az adatbázis frissítése
                    int rowsUpdated = adapter.Update(table);
                    MessageBox.Show($"{rowsUpdated} sor módosítva!");

                    // A DataGrid frissítése
                    selectedRow.Row["column_name1"] = newValue; // A módosított érték frissítése a DataGrid-ben
                    CarDataGrid.ItemsSource = table.DefaultView;
                }
                else
                {
                    MessageBox.Show("Válasszon ki egy sort a módosításhoz.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hiba történt az adat módosításakor: " + ex.Message);
            }
        }

        // Adat törlése
        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (CarDataGrid.SelectedIndex >= 0)
                {
                    // Kiválasztott sor azonosítása index alapján
                    DataRowView selectedRow = (DataRowView)CarDataGrid.Items[CarDataGrid.SelectedIndex];

                    string selectedId = selectedRow.Row["id"].ToString(); // Az id mező alapján töröljük

                    // Az adatbázisból való törlés SQL parancsa
                    string query = $"DELETE FROM {TableComboBox.SelectedItem.ToString()} WHERE id = @id";
                    using (MySqlConnection conn = new MySqlConnection(ConnectionString))
                    {
                        MySqlCommand cmd = new MySqlCommand(query, conn);
                        cmd.Parameters.AddWithValue("@id", selectedId);

                        conn.Open();
                        cmd.ExecuteNonQuery();
                    }

                    // A DataGrid-ben is töröljük a rekordot
                    selectedRow.Row.Delete();
                    int rowsDeleted = adapter.Update(table);
                    MessageBox.Show($"{rowsDeleted} sor törölve!");
                }
                else
                {
                    MessageBox.Show("Válasszon ki egy sort a törléshez.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hiba történt az adat törlésekor: " + ex.Message);
            }
        }
    }
}
