﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using MySql.Data.MySqlClient;

namespace Kocsi_Asztali_App
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            string connectionData = "server=localhost;database=auto_adatbázis;uid=root;pwd=root";
            MySqlConnection szinek = new MySqlConnection(connectionData);
            try
            {
                szinek.Open();
                string query = "SELECT Szín FROM színek";
                MySqlCommand cmd = new MySqlCommand(query, szinek);
                MySqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    Autok.Items.Add(reader["Szín"]);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Adatbázis kapcsolati hiba!", "Hiba", MessageBoxButton.OKCancel, MessageBoxImage.Error);
            }
            finally
            {
                szinek.Close();
            }
        }

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Ellenőrizzük, hogy a ComboBox-ban valóban ki lett-e választva egy elem
            if (Autok.SelectedItem == null)
                return;

            Lista.Items.Clear();
            string connectionData = "server=localhost;database=auto_adatbázis;uid=root;pwd=root";
            MySqlConnection szinek = new MySqlConnection(connectionData);
            try
            {
                szinek.Open();
                string valasztottSzin = Autok.SelectedItem.ToString();

                // Lekérdezés az autókra, amelyek megfelelnek a kiválasztott színnek
                string query = "SELECT autók.* FROM autók JOIN színek ON autók.`Szín ID` = színek.`Szín azonosító` WHERE színek.`Szín` = @szin";
                MySqlCommand cmd = new MySqlCommand(query, szinek);
                cmd.Parameters.AddWithValue("@szin", valasztottSzin);

                MySqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    string autoTulajdonsagok = $"Rendszám: {reader["10"]}, Márka: {reader["Márka ID"]}, Modell: {reader["Modell ID"]}, Évjárat: {reader["Évjárat"]}, Km állás: {reader["Kilométeróra állás"]}, Motortípus: {reader["Motortípus ID"]}, Motorspecifikáció: {reader["Motorspecifikáció ID"]}, Használat: {reader["Használat ID"]}, Sebességváltó: {reader["Sebességváltó ID"]}, Ár: {reader["Ár"]}, Eladó: {reader["Eladó ID"]}";
                    Lista.Items.Add(autoTulajdonsagok);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Adatbázis kapcsolati hiba: {ex.Message}", "Hiba", MessageBoxButton.OKCancel, MessageBoxImage.Error);
            }
            finally
            {
                szinek.Close();
            }
        }

        private void Autok_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
        }
    }
}
