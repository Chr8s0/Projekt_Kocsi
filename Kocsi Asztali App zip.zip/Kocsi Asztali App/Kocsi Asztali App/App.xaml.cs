﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace Kocsi_Asztali_App
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
